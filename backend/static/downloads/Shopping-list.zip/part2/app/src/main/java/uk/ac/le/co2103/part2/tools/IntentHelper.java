package uk.ac.le.co2103.part2.tools;

import android.content.Context;
import android.content.Intent;

public class IntentHelper {
    public static final String EXTRA_KEY = "extra_key";

    public static void openCreateIntent(Context context, Class passTO, int flags) {
        Intent i = new Intent(context, passTO);

        i.setFlags(flags | Intent.FLAG_ACTIVITY_CLEAR_TOP);

        context.startActivity(i);
    }
    public static void openIntent(Context context, Class passTO) {
        Intent i = new Intent(context, passTO);
        context.startActivity(i);
    }


    public static void openIntentPassID(Context context, Class<?> passTo,  int extraData) {
        Intent i = new Intent(context, passTo);
        // Add extra data to the intent
        i.putExtra(EXTRA_KEY, extraData);

        context.startActivity(i);
    }

    public static void openIntentPassName(Context context, Class<?> passTo,  String extraData) {
        Intent i = new Intent(context, passTo);

        // Add extra data to the intent
        i.putExtra(EXTRA_KEY, extraData);

        context.startActivity(i);
    }
}
