package uk.ac.le.co2103.part2;

import android.content.Context;

import androidx.lifecycle.LiveData;

import java.util.List;

public class ListRepository {
    private ShoppingListDB shoppingListDB;
    private ShoppingListDao shoppingListDao;


    public ListRepository(Context context) {
        shoppingListDB = ShoppingListDB.getDatabase(context);
        shoppingListDao = ShoppingListDB.getDatabase(context).shoppingListDao();
    }

    public LiveData<List<ShoppingList>> getAllLists() {
        return (LiveData<List<ShoppingList>>) shoppingListDB.shoppingListDao().getAllLists();
    }

    public void insert(ShoppingList shoppingList) {
        ShoppingListDB.databaseWriteExecutor.execute(() -> {
            shoppingListDB.shoppingListDao().insert(shoppingList);
        });
    }
    public void deleteShoppingListAndProducts(ShoppingList shoppingList) {
        int shoppingListId = shoppingList.getListID();

        // Delete associated products first
        shoppingListDao.deleteProductsForShoppingList(shoppingListId);

        // Then delete the shopping list
        shoppingListDao.delete(shoppingList);
    }

    public LiveData<String> getListNameById(int listId) {
        return shoppingListDao.getListNameById(listId);
    }

    public LiveData<ShoppingList> getListByName(String name) {
        return shoppingListDao.getListByName(name);
    }
}