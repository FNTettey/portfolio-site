package uk.ac.le.co2103.part2;

import android.graphics.Bitmap;
import android.media.Image;
import android.net.Uri;

import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;
import androidx.room.Relation;

import java.util.ArrayList;
import java.util.List;
@Entity
public class ShoppingList {
    @PrimaryKey(autoGenerate = true)
    private int listID;

    private String name;
    private String  imageUri;

    public ShoppingList(String name, String imageUri) {
        this.name = name;
        this.imageUri = imageUri;
    }
    @Ignore

    public ShoppingList(String name) {
        this.name = name;
    }

    public int getListID() {
        return listID;
    }

    public void setListID(int listID) {
        this.listID = listID;
    }

    public String getName() {
        return name;
    }

    public String getImageUri() {
        return imageUri;
    }

    public void setImageUri(String imageUri) {
        this.imageUri = imageUri;
    }

    public void setName(String name) {
        this.name = name;
    }

}
