package uk.ac.le.co2103.part2.Activities;

import static androidx.constraintlayout.motion.utils.Oscillator.TAG;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

import uk.ac.le.co2103.part2.Adaptors.ProductAdapter;
import uk.ac.le.co2103.part2.ListRepository;
import uk.ac.le.co2103.part2.Product;
import uk.ac.le.co2103.part2.ProductRepository;
import uk.ac.le.co2103.part2.R;
import uk.ac.le.co2103.part2.tools.IntentHelper;

public class ShoppingListActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ProductAdapter adapter;
    private ProductRepository productRepository;
    private int shoppingListId;
    private TextView listName;
    private ListRepository listRepository;
    public static MutableLiveData<Boolean> refreshTrigger = new MutableLiveData<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shopping_list);

        // Retrieve the ID passed from MainActivity
        shoppingListId = getIntent().getIntExtra(IntentHelper.EXTRA_KEY, -1);
        listName = findViewById(R.id.listNameHeader);
        listRepository = new ListRepository(this);
        // Initialize RecyclerView
        recyclerView = findViewById(R.id.recyclerview_product);
        adapter = new ProductAdapter(this, new ArrayList<>());
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        // Initialize ProductRepository
        productRepository = new ProductRepository(this);

        // Observe changes in the product list
        productRepository.getProductsForShoppingList(shoppingListId).observe(this, new Observer<List<Product>>() {
            @Override
            public void onChanged(List<Product> products) {
                // Update the adapter with the new data
                adapter.updateData(products);
            }
        });

        listRepository.getListNameById(shoppingListId).observe(this, new Observer<String>() {
            @Override
            public void onChanged(String name) {
                // Update the listName TextView with the list name
                listName.setText(name);
            }
        });

        final FloatingActionButton button_add = findViewById(R.id.fabAddProduct);
        button_add.setOnClickListener(view -> {
            IntentHelper.openIntentPassID(this, AddProductActivity.class, shoppingListId);
            Log.d(TAG, "Floating action button clicked.");
            Toast.makeText(getApplicationContext(), "Adding new Product", Toast.LENGTH_LONG).show();
        });

        final FloatingActionButton button_back = findViewById(R.id.fabBackToMain);
        button_back.setOnClickListener(view -> {
            IntentHelper.openIntent(this, MainActivity.class);
            Log.d(TAG, "Floating action button clicked.");
            Toast.makeText(getApplicationContext(), "Home", Toast.LENGTH_LONG).show();
        });

        refreshTrigger.observe(this, new Observer<Boolean>() {
            @Override
            public void onChanged(Boolean trigger) {
                // Refresh the UI when the refresh trigger is set to true
                if (trigger) {
                    // Update the adapter with the new data
                    productRepository.getProductsForShoppingList(shoppingListId).observe(ShoppingListActivity.this, new Observer<List<Product>>() {
                        @Override
                        public void onChanged(List<Product> updatedProducts) {
                            adapter.updateData(updatedProducts);
                            // Set trigger back to false to prevent unnecessary refreshes
                            refreshTrigger.setValue(false);
                        }
                    });
                }
            }
        });

    }

    public void onItemClick(Product product) {
        // Display a dialog with options to edit or delete the selected product
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Options")
                .setItems(new CharSequence[]{"Edit", "Delete"}, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which) {
                            case 0:
                                // Edit option selected, open UpdateProductActivity

                                IntentHelper.openIntentPassName(ShoppingListActivity.this, UpdateProductActivity.class, product.getName());
                                break;
                            case 1:
                                productRepository.delete(product);
                                refreshTrigger.setValue(true);
                                Toast.makeText(ShoppingListActivity.this, "Item Deleted, It will be gone when you next open the list", Toast.LENGTH_SHORT).show();
                                break;
                        }
                    }
                });
        builder.create().show();
    }
}
