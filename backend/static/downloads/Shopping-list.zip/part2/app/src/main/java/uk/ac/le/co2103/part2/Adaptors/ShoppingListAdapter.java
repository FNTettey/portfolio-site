package uk.ac.le.co2103.part2.Adaptors;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import uk.ac.le.co2103.part2.Activities.ShoppingListActivity;
import uk.ac.le.co2103.part2.R;
import uk.ac.le.co2103.part2.ShoppingList;
import uk.ac.le.co2103.part2.tools.ImageUtils;
import uk.ac.le.co2103.part2.tools.IntentHelper;

public class ShoppingListAdapter extends RecyclerView.Adapter<ShoppingListAdapter.ViewHolder> {

    private Context context;
    private List<ShoppingList> shoppingLists;

    public ShoppingListAdapter(Context context, List<ShoppingList> shoppingLists) {
        this.context = context;
        this.shoppingLists = shoppingLists;
    }

    public interface OnShoppingListClickListener {
        void onShoppingListClick(ShoppingList shoppingList);
    }

    private OnShoppingListClickListener clickListener;

    public void setOnShoppingListClickListener(OnShoppingListClickListener listener) {
        this.clickListener = listener;
    }

    public interface OnShoppingListLongClickListener {
        void onShoppingListLongClick(ShoppingList shoppingList);
    }

    private OnShoppingListLongClickListener longClickListener;

    public void setOnShoppingListLongClickListener(OnShoppingListLongClickListener listener) {
        this.longClickListener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recyclerview_list, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.bind(shoppingLists.get(position));
    }

    @Override
    public int getItemCount() {
        return shoppingLists.size();
    }
    public void setShoppingLists(List<ShoppingList> shoppingLists) {
        this.shoppingLists = shoppingLists;
    }

    public void updateData(List<ShoppingList> newShoppingLists) {
        if (newShoppingLists != null) {
            shoppingLists.clear();
            shoppingLists.addAll(newShoppingLists);
            notifyDataSetChanged();
        }
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private ImageView listImage;
        private TextView listName;
        private ShoppingList shoppingList;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            listImage = itemView.findViewById(R.id.listImage);
            listName = itemView.findViewById(R.id.listName);
            itemView.setOnClickListener(view -> {
                if (clickListener != null){
                    clickListener.onShoppingListClick(shoppingList);
                }

            });



            itemView.setOnLongClickListener(view -> {
                // Handle long click here
                if (longClickListener != null) {
                    longClickListener.onShoppingListLongClick(shoppingList);
                    return true;
                }
                return false;
            });

        }

        public void bind(ShoppingList shoppingList) {
            this.shoppingList = shoppingList;

            listName.setText(shoppingList.getName());
            if (shoppingList.getImageUri() != null) {
                ImageUtils.setImageViewFromString(context, listImage, shoppingList.getImageUri());
                listImage.setVisibility(View.VISIBLE);
            } else {
                listImage.setVisibility(View.INVISIBLE);
            }
        }
    }
}
