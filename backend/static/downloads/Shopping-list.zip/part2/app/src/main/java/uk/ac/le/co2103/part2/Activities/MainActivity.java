package uk.ac.le.co2103.part2.Activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

import uk.ac.le.co2103.part2.Adaptors.ShoppingListAdapter;
import uk.ac.le.co2103.part2.ListRepository;
import uk.ac.le.co2103.part2.R;
import uk.ac.le.co2103.part2.ShoppingList;
import uk.ac.le.co2103.part2.ShoppingListDB;
import uk.ac.le.co2103.part2.tools.IntentHelper;

public class MainActivity extends AppCompatActivity  implements ShoppingListAdapter.OnShoppingListLongClickListener, ShoppingListAdapter.OnShoppingListClickListener {
    private static final int REQUEST_STORAGE_PERMISSION = 100;
    private static final String TAG = MainActivity.class.getSimpleName();
    private RecyclerView recyclerView;
    private ShoppingListAdapter adapter;
    private ShoppingListDB shoppingListDB;
    private ListRepository listRepository;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Log.d(TAG, "onCreate()");
        setContentView(R.layout.activity_main);
        shoppingListDB = ShoppingListDB.getDatabase(this);
        recyclerView = findViewById(R.id.recyclerview);
        adapter = new ShoppingListAdapter(this, new ArrayList<>());
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
        listRepository = new ListRepository(this);
        adapter.setOnShoppingListLongClickListener(this);
        adapter.setOnShoppingListClickListener(this);


        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQUEST_STORAGE_PERMISSION);
        } else {
            // Permission already granted, proceed with loading images
            loadShoppingLists();
        }


        final FloatingActionButton button = findViewById(R.id.fab);
        button.setOnClickListener(view -> {
            IntentHelper.openIntent(this, CreateListActivity.class);
            Log.d(TAG, "Floating action button clicked.");
            Toast.makeText(getApplicationContext(), "Adding new List", Toast.LENGTH_LONG).show();
        });
    }

    private void loadShoppingLists() {
        new Thread(() -> {
            List<ShoppingList> shoppingLists = shoppingListDB.shoppingListDao().getAllLists();
            runOnUiThread(() -> adapter.updateData(shoppingLists));
        }).start();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_STORAGE_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, proceed with loading images
                loadShoppingLists();
            } else {
                // Permission denied, show a message or handle accordingly
                Toast.makeText(this, "Permission denied. Cannot load images.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void onShoppingListClick(ShoppingList shoppingList) {
        // Handle short click here
        IntentHelper.openIntentPassID(this, ShoppingListActivity.class, shoppingList.getListID());
    }
    public void onShoppingListLongClick(ShoppingList shoppingList) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete Shopping List");
        builder.setMessage("Are you sure you want to delete this shopping list?");
        builder.setPositiveButton("Delete", (dialog, which) -> {
            // Execute the deletion operation on a background thread
            new Thread(() -> {
                deleteShoppingListInBackground(shoppingList);
            }).start();
            Toast.makeText(this, "List: "+shoppingList.getName()+" Deleted", Toast.LENGTH_SHORT).show();
        });
        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    private void deleteShoppingListInBackground(ShoppingList shoppingList) {
        listRepository.deleteShoppingListAndProducts(shoppingList);

        // After deletion, fetch updated shopping lists on a background thread
        new Thread(() -> {
            List<ShoppingList> updatedShoppingLists = shoppingListDB.shoppingListDao().getAllLists();
            // Update the UI on the main thread
            runOnUiThread(() -> {
                adapter.setShoppingLists(updatedShoppingLists);
                adapter.notifyDataSetChanged();
            });
        }).start();
    }



}