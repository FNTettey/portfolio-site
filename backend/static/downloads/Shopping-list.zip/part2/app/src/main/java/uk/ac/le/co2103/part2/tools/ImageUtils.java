package uk.ac.le.co2103.part2.tools;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.widget.ImageView;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

public class ImageUtils {
    //Used for storing the image in a list class and displaying it in the app
    public static String uriToString(Uri uri) {
        return uri.toString();
    }

    public static void setImageViewFromString(Context context, ImageView imageView, String uriString) {
        Uri uri = Uri.parse(uriString);
        try {
            Bitmap bitmap = uriToBitmap(context, uri);
            imageView.setImageBitmap(bitmap);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static Bitmap uriToBitmap(Context context, Uri uri) throws IOException {
        InputStream inputStream = context.getContentResolver().openInputStream(uri);
        Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
        inputStream.close();
        return bitmap;
    }
}
