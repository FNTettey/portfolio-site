package uk.ac.le.co2103.part2.Activities;

import static android.content.ContentValues.TAG;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import uk.ac.le.co2103.part2.ListRepository;
import uk.ac.le.co2103.part2.R;
import uk.ac.le.co2103.part2.ShoppingList;
import uk.ac.le.co2103.part2.tools.ImageUtils;
import uk.ac.le.co2103.part2.tools.IntentHelper;

public class CreateListActivity extends AppCompatActivity {
    private ActivityResultLauncher<String> imagePickerLauncher;
    private ImageView img_newList;
    private Button bt_create;
    private Uri selectedImageUri;
    private EditText et_newListName;
    private ListRepository listRepository;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_list);
        img_newList = findViewById(R.id.img_newList);
        bt_create=findViewById(R.id.bt_create);
        et_newListName = findViewById(R.id.et_newListName);
        listRepository = new ListRepository(getApplication());



        img_newList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openGallery();
            }
        });


        imagePickerLauncher = registerForActivityResult(
                new ActivityResultContracts.GetContent(),
                uri -> {
                    // Handle the selected image URI here
                    if (uri != null) {

                        img_newList.setImageURI(uri);
                        selectedImageUri = uri;
                    }
                })
        ;

        bt_create.setOnClickListener(view -> {
            // Get the name from the EditText
            String newListName = et_newListName.getText().toString().trim();

            // Check if the name is empty
            if (newListName.isEmpty()) {
                // If the name is empty, display a message or handle the scenario accordingly
                Toast.makeText(getApplicationContext(), "Please enter a name for the list", Toast.LENGTH_SHORT).show();
                return;
            }

            // Check if a list with the same name already exists
            LiveData<ShoppingList> existingListObserver = listRepository.getListByName(newListName);
            existingListObserver.observe(this, new Observer<ShoppingList>() {
                @Override
                public void onChanged(ShoppingList existingList) {
                    // Remove the observer after it has been triggered
                    existingListObserver.removeObserver(this);

                    if (existingList != null) {
                        // A list with the same name already exists, display a toast message
                        Toast.makeText(getApplicationContext(), "A list with the same name already exists", Toast.LENGTH_SHORT).show();
                    } else {
                        // No list with the same name exists, proceed to create the new list

                        // Check if an image is selected
                        if (selectedImageUri != null) {
                            ShoppingList newList = new ShoppingList(newListName, ImageUtils.uriToString(selectedImageUri));
                            listRepository.insert(newList);
                        } else {
                            ShoppingList newList = new ShoppingList(newListName);
                            listRepository.insert(newList);
                        }

                        // Display a toast message for successful creation
                        Toast.makeText(getApplicationContext(), "New List Created", Toast.LENGTH_LONG).show();

                        // Navigate back to the MainActivity
                        startActivity(new Intent(CreateListActivity.this, MainActivity.class));
                    }
                }
            });
        });


    }
    private void openGallery() {
        imagePickerLauncher.launch("image/*");



    }
}