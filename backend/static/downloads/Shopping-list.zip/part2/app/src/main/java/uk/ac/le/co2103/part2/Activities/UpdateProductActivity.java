package uk.ac.le.co2103.part2.Activities;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import uk.ac.le.co2103.part2.Product;
import uk.ac.le.co2103.part2.ProductRepository;
import uk.ac.le.co2103.part2.R;
import uk.ac.le.co2103.part2.tools.IntentHelper;

public class UpdateProductActivity extends AppCompatActivity {

    private EditText editTextNameUpdate;
    private EditText editTextQuantityUpdate;
    private Spinner spinnerUpdate;
    private Button bt_addProductUpdate;
    private FloatingActionButton quantityAddButton;
    private FloatingActionButton quantityMinusButton;
    private String productName;
    private int shoppingListId;

    private ProductRepository productRepository;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_product);

        // Retrieve the ID passed from ShoppingListActivity
        productName = getIntent().getStringExtra(IntentHelper.EXTRA_KEY);

        // Initialize views
        editTextNameUpdate = findViewById(R.id.editTextNameUpdate);
        editTextQuantityUpdate = findViewById(R.id.editTextQuantityUpdate);
        spinnerUpdate = findViewById(R.id.spinnerUpdate);
        bt_addProductUpdate = findViewById(R.id.bt_addProductUpdate);
        quantityAddButton = findViewById(R.id.quantityAddButton);
        quantityMinusButton = findViewById(R.id.quantityMinusButton);

        // Initialize ProductRepository
        productRepository = new ProductRepository(this);

        productRepository.getProductByName(productName).observe(this, new Observer<Product>() {
            @Override
            public void onChanged(Product product) {
                if(product != null) {
                    // Fill in the EditText and Spinner with product details
                    editTextNameUpdate.setText(product.getName());
                    editTextQuantityUpdate.setText(String.valueOf(product.getQuantity()));
                    // Set the selected item in the Spinner
                    String unit = product.getUnit();
                    shoppingListId=product.getShoppingListId();
                    ArrayAdapter<CharSequence> adapter = (ArrayAdapter<CharSequence>) spinnerUpdate.getAdapter();
                    if (adapter != null) {
                        int position = adapter.getPosition(unit);
                        spinnerUpdate.setSelection(position);
                    }
                } else {
                    // Handle the case where the product is not found
                    Toast.makeText(UpdateProductActivity.this, "Product not found", Toast.LENGTH_SHORT).show();
                    // Finish the activity
                    finish();
                }
            }
        });


        // Set click listeners
        bt_addProductUpdate.setOnClickListener(v -> addProduct());
        quantityAddButton.setOnClickListener(v -> incrementQuantity());
        quantityMinusButton.setOnClickListener(v -> decrementQuantity());
    }

    private void addProduct() {
        String name = editTextNameUpdate.getText().toString().trim();
        String quantityString = editTextQuantityUpdate.getText().toString().trim();
        String unit = spinnerUpdate.getSelectedItem().toString();

        // Check if name or quantity is empty
        if (name.isEmpty() || quantityString.isEmpty()) {
            Toast.makeText(this, "Please enter product name and quantity", Toast.LENGTH_SHORT).show();
            return;
        }

        // Convert quantity to integer
        int quantity = Integer.parseInt(quantityString);

        // Create the Product object with updated values
        Product updatedProduct = new Product(name, quantity, unit);
        updatedProduct.setShoppingListId(shoppingListId);

        // Update the product in the database
        productRepository.update(updatedProduct);

        String toastMessage = "";
        if (quantity> 1 && unit.equals("Unit")){
            toastMessage = quantity + " units of " + name;
        }
        else{
            toastMessage = quantity + " " + unit + " of " + name;
        }

        // Show a toast message
        Toast.makeText(this, "Product updated successfully: "+toastMessage, Toast.LENGTH_SHORT).show();
        ShoppingListActivity.refreshTrigger.setValue(true);

        // Finish the activity and return to ShoppingListActivity
        finish();
    }

    private void incrementQuantity() {
        // Increment the quantity when the "+" button is clicked
        int currentQuantity = Integer.parseInt(editTextQuantityUpdate.getText().toString());
        currentQuantity++;
        editTextQuantityUpdate.setText(String.valueOf(currentQuantity));
    }

    private void decrementQuantity() {
        // Decrement the quantity when the "-" button is clicked
        int currentQuantity = Integer.parseInt(editTextQuantityUpdate.getText().toString());
        if (currentQuantity > 0) {
            currentQuantity--;
            editTextQuantityUpdate.setText(String.valueOf(currentQuantity));
        }
    }

}
