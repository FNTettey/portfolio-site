package uk.ac.le.co2103.part2.Activities;

import static androidx.constraintlayout.motion.utils.Oscillator.TAG;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import uk.ac.le.co2103.part2.Adaptors.ProductAdapter;
import uk.ac.le.co2103.part2.Adaptors.ShoppingListAdapter;
import uk.ac.le.co2103.part2.Product;
import uk.ac.le.co2103.part2.ProductRepository;
import uk.ac.le.co2103.part2.R;
import uk.ac.le.co2103.part2.tools.IntentHelper;

public class AddProductActivity extends AppCompatActivity {
    private ExecutorService executorService = Executors.newSingleThreadExecutor();
    private ProductAdapter adapter;
    private EditText editTextName;
    private EditText editTextQuantity;
    private Spinner spinner;
    private Button btAddProduct;
    private int shoppingListId;
    private ProductRepository productRepository;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_product);

        // Retrieve the ID passed from ShoppingListActivity
        shoppingListId = getIntent().getIntExtra(IntentHelper.EXTRA_KEY, -1);

        // Initialize views
        editTextName = findViewById(R.id.editTextName);
        editTextQuantity = findViewById(R.id.editTextQuantity);
        spinner = findViewById(R.id.spinner);
        btAddProduct = findViewById(R.id.bt_addProduct);

        // Initialize ProductRepository
        productRepository = new ProductRepository(this);

        // Add click listener to the "Add" button
        btAddProduct.setOnClickListener(v -> addProduct());
    }

    private void addProduct() {
        String name = editTextName.getText().toString().trim();
        String quantityString = editTextQuantity.getText().toString().trim();
        String unit = spinner.getSelectedItem().toString();

        // Check if name or quantity is empty
        if (TextUtils.isEmpty(name) || TextUtils.isEmpty(quantityString)) {
            Toast.makeText(this, "Please enter product name and quantity", Toast.LENGTH_SHORT).show();
            return;
        }

        // Convert quantity to integer
        int quantity = Integer.parseInt(quantityString);

        // Create the Product object
        Product product = new Product(name, quantity, unit);
        product.setShoppingListId(shoppingListId);

        productRepository.productExistsInShoppingList(name, shoppingListId, exists -> {
            if (exists) {
                runOnUiThread(() -> Toast.makeText(AddProductActivity.this, "Product already exists in the list", Toast.LENGTH_SHORT).show());
            } else {
                // Insert the product into the database
                productRepository.insert(product);

                // Display toast message with product details
                String toastMessage = "";
                if (quantity> 1 && unit.equals("Unit")){
                    toastMessage = quantity + " units of " + name;
                }
                else{
                    toastMessage = quantity + " " + unit + " of " + name;
                }

                String finalToastMessage = toastMessage;
                runOnUiThread(() -> Toast.makeText(getApplicationContext(), finalToastMessage, Toast.LENGTH_LONG).show());

                // Navigate back to the ShoppingListActivity
                IntentHelper.openIntentPassID(AddProductActivity.this, ShoppingListActivity.class, shoppingListId);
            }
        });
    }

}
