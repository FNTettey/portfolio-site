package uk.ac.le.co2103.part2;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface ShoppingListDao {
    @Insert
    void insert(ShoppingList shoppingList);


    @Update
    void update(ShoppingList shoppingList);

    @Delete
    void delete(ShoppingList shoppingList);

    @Query("SELECT * FROM ShoppingList")
    List<ShoppingList> getAllLists();
    @Query("SELECT * FROM Product WHERE shoppingListId = :shoppingListId")
    List<Product> getProductsForShoppingList(int shoppingListId);

    // Define a method to delete all products associated with a specific shopping list
    @Query("DELETE FROM Product WHERE shoppingListId = :shoppingListId")
    void deleteProductsForShoppingList(int shoppingListId);
    @Delete
    void deleteShoppingList(ShoppingList shoppingList);

    @Query("SELECT name FROM ShoppingList WHERE listID = :listId")
    LiveData<String> getListNameById(int listId);

    @Query("SELECT * FROM ShoppingList WHERE name = :name")
    LiveData<ShoppingList> getListByName(String name);
}