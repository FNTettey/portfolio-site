package uk.ac.le.co2103.part2;

import android.content.Context;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ProductRepository {
    private ExecutorService executorService = Executors.newSingleThreadExecutor();

    private final ProductDao productDao;

    public ProductRepository(Context context) {
        ShoppingListDB db = ShoppingListDB.getDatabase(context);
        productDao = db.productDao();
    }

    public void insert(Product product) {
        executorService.execute(() -> {
            productDao.insertProduct(product);
        });
    }

    public void update(Product product) {
        executorService.execute(() -> {
            productDao.updateProduct(product);
        });
    }
    public interface ProductExistsCallback {
        void onProductExists(boolean exists);
    }

    public void productExistsInShoppingList(String name, int shoppingListId, ProductExistsCallback callback) {
        executorService.execute(() -> {
            boolean exists = productDao.getProductByNameAndListId(name, shoppingListId) != null;
            callback.onProductExists(exists);
        });
    }

    private static class InsertProductAsyncTask extends AsyncTask<Product, Void, Void> {

        private final ProductDao productDao;

        InsertProductAsyncTask(ProductDao productDao) {
            this.productDao = productDao;
        }

        @Override
        protected Void doInBackground(Product... products) {
            productDao.insertProduct(products[0]);
            return null;
        }
    }
    public LiveData<List<Product>> getProductsForShoppingList(int shoppingListId) {
        MutableLiveData<List<Product>> liveData = new MutableLiveData<>();
        new GetProductsTask(productDao, liveData).execute(shoppingListId);
        return liveData;
    }

    private static class GetProductsTask extends AsyncTask<Integer, Void, List<Product>> {
        private ProductDao productDao;
        private MutableLiveData<List<Product>> liveData;

        public GetProductsTask(ProductDao productDao, MutableLiveData<List<Product>> liveData) {
            this.productDao = productDao;
            this.liveData = liveData;
        }

        @Override
        protected List<Product> doInBackground(Integer... integers) {
            // Perform database operation in a background thread
            return productDao.getProductsForShoppingList(integers[0]);
        }

        @Override
        protected void onPostExecute(List<Product> products) {
            // Update LiveData with the result
            liveData.setValue(products);
        }
    }
    public LiveData<Product> getProductByName(String productName) {
        MutableLiveData<Product> liveData = new MutableLiveData<>();
        executorService.execute(() -> {
            Product product = productDao.getProductByName(productName);
            liveData.postValue(product);
        });
        return liveData;
    }
    public void delete(Product product) {
        executorService.execute(() -> {
            productDao.deleteProduct(product);
        });
    }


}
