package uk.ac.le.co2103.part2;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface ProductDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void insertProduct(Product product);

    @Query("SELECT * FROM Product WHERE shoppingListId = :shoppingListId")
   List<Product> getProductsForShoppingList(int shoppingListId);

    @Query("SELECT * FROM Product WHERE name = :name AND shoppingListId = :shoppingListId LIMIT 1")
    Product getProductByNameAndListId(String name, int shoppingListId);

    @Query("SELECT * FROM Product WHERE name = :productName")
    Product getProductByName(String productName);

    @Update
    void updateProduct(Product product);

    @Delete
    void deleteProduct(Product product);


}